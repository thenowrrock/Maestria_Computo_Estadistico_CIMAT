#include <iostream>
using namespace std;

int main(){
	
	int n;

	cout << "Dame un numero entero: " << endl;
	cin >> n;

	cout << "El valor de n es: " << n << endl;	

	return 0;
}
